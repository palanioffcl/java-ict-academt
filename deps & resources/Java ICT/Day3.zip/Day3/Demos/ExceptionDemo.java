package exceptions;

import java.io.IOException;

public class ExceptionDemo {
	
	public static void main(String args[]) // throws Exception 
	{
	  	 // try
	   // {   
    int a=5/0;
	   // } 
	/* catch(ArithmeticException e)
	{
		   System.out.println("u are dividing by 0");
	 //  e.printStackTrace();
		 
	}  */  
	System.out.println("continue");
	}

}

