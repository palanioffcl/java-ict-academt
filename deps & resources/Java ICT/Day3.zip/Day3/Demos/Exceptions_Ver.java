package exceptions;
public class Exceptions_Ver{  
    public static void main(String Args[]) {  

         int[] array = new int[3];  

         try{              

             for(int i=0;i<3;++i){  

                 array[i] = i;  

             }
              
             System.out.println(array[8]);
            
            array[0] = 2/0;  
            
         }
         
        
        
         catch(ArithmeticException e1){  

             System.out.println("Cannot Divide by Zero!");  

         }      
        
        catch(ArrayIndexOutOfBoundsException e){  
              // e.printStackTrace();
             System.out.println("Oops, we went to far, better go back to 0!");  
 
         } 
 
         catch( Exception e){  
             // e.printStackTrace();
            System.out.println(e);  

        } 

      
 
         finally{  

             System.out.println("Will be called always");  
         

         }  
         
        
     }  

 } 

