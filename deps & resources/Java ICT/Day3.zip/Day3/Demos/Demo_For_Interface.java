package com.pack8;
/** A Demo*/
  class Demo_For_Interface implements I {

	public void add()
	{
			System.out.println("in add method of interface");
	}
	
	  public void show1()
	{
		
		System.out.println("in overridden show ");	
	}  
	
	 
	public static void main(String[] args) {
		 
		Demo_For_Interface obj=new Demo_For_Interface();
		obj.add();
		obj.show();
		I.show1();
		 

	}

}
