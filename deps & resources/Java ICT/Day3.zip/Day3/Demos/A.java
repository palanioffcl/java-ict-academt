package nestedclass;

//Inner class can access even private members of outer class.
//Outer class can access even private members of inner class through inner class objects.
//Inner class can be Static class . Adv - if we do not want to create objects for a class
//Static class can take only static members

   class C {
	
 	private  int p=90;
 	
 	B b=new B();
	 
	void meth2()
	{
		
		System.out.println(b.x);
	 
	}
	
	   class B
	{
		private int x=25;
		  
	 	void meth1()
		{
			System.out.println(p);
		}
	} 
  }
	 class A extends C
	 {
    public static void main(String[] args){
	{
		
		 
		 
		C obj=new C();
	 
	  
		B obj1=new C().new B();
	 
	 		 
	//	B obj1=obj.new B();
		 
	 
		obj1.meth1();
		obj.meth2();
	 
	}

}
  } 
