import java.util.*;
 
class Student1
{
 	int id;
	String name;
	
	void accept()
	{
		Scanner scan=new Scanner(System.in);
		id=scan.nextInt();
		name=scan.next();
	}	
}

public class StudentArray {

	public static void main(String args[])
	{
	 	 
		Student1 studs[]=new Student1[3];
		for (int i=0;i<studs.length;i++)
		{
					 
		System.out.println("Enter id and name");	 
		studs[i]=new Student1();
					
		studs[i].accept(); 
		}
   
		
		for (int i=0;i<studs.length;i++)
		{

         System.out.println(studs[i].id);

	}
	}

}









/*ArrayList<Student1>  newStudentList = new ArrayList<Student1>();
newStudentList.addAll(Arrays.asList(studs));

for (Student1 s: newStudentList)
// for (int i=0;i< newStudentList.size();i++)
//{
	 System.out.println(s);*/
// System.out.println("From AL "+ newStudentList.get(i).id);
// System.out.println("From AL "+ newStudentList.get(i).name);
