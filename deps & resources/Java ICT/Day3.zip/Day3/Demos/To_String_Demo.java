// Object 
   class To_String_Demo {

	int a=10;
	String b="Hello";
	
	   
	public static void main(String args[])
	{
		
		To_String_Demo obj=new To_String_Demo();
		System.out.println(obj);
	}
	 
	
	  public String toString() { 
		  return a+" "+b; 
		  }
	 
 
	
   }

