	package com.pack;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
 

public class MyMain {

	 
	public static void main(String[] args)throws Exception {
		
	    
			 SessionFactory sessions = new Configuration().configure().buildSessionFactory();
		        
		        Session session = sessions.openSession();                                    
	  
	 
	        Transaction tx = null;
	       
	     
	        try
	        {
	            tx=session.beginTransaction();
	        	Login obj=new Login();
	        	
	          	obj.setUsername("aaaaag");
	        	obj.setPassword("bbbbhn");
	        
	        	
	                 	                        
	        	session.save(obj);
	        	System.out.print("Values added");
	        	tx.commit();
           
	       }
	        catch (HibernateException e)
	        {
	        	 
	           tx.rollback();
	           System.out.println("Rolled back");
	           System.out.println(e);
	        }
	         finally
	         {
	        	 
	           session.close();
	        }


	}

}
