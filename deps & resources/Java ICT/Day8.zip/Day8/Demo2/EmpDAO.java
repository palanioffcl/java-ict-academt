package  pack1;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;

 
public class EmpDAO {
	  
	public   int  insert(Employee e) 
			  
	{
		Connection c=null;
		int res=0;
		PreparedStatement ps=null;
		 		 try
		 {
		  c= CommonCon.Connect();
	 ps=c.prepareStatement("insert into employee values(?,?,?,?,?)");
		ps.setInt(1,e.getEmpNo());
		ps.setString(2,e.getEmpName());
		ps.setString(3,e.getJob());
		ps.setDate(4,e.getHdate());
		ps.setInt(5,e.getDno());
		res=ps.executeUpdate();	
		 }
		 catch(SQLException ex)
		 {
			 
			 System.out.println(ex);
		 }
		 finally
		 {
			 
			 try {
				ps.close();
				 c.close();
			} catch (SQLException ex) {
				 
				ex.printStackTrace();
			}
			
		 }
		 		 return res;
	}

}
