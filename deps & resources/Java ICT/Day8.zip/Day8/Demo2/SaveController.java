package pack1;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Save
 */
public class SaveController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	EmpDAO empDao=new EmpDAO();
    Employee emp=new Employee();
    public SaveController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	
		
		try
	{
		PrintWriter out=response.getWriter();
	 
		String en=request.getParameter("eno");
		String enam=request.getParameter("ename");
	    String jb=request.getParameter("job");
		String hd=request.getParameter("hdate");
		String dp=request.getParameter("dept");
		  
		 int db_en=Integer.parseInt(en);
		
		 SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy"); 
		 java.util.Date  hdate=sdf.parse(hd);
  		 java.sql.Date db_hd=new java.sql.Date(hdate.getTime());
  		 
        int db_dn=Integer.parseInt(dp);
		  System.out.println(en+enam+jb+hd+dp);
		  
		  emp.setEmpNo(db_en);
		  emp.setEmpName(enam);
		  emp.setJob(jb);
		  emp.setHdate(db_hd);
		  emp.setDno(db_dn);
		  
		 int res= empDao.insert(emp);
		 if(res>=1)
		out.println("Inserted");
		  
	}
	catch (Exception e)
	{
		 
		System.out.println(e);
	}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
