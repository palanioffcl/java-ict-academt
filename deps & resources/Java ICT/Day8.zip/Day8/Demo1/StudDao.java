package pack1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class StudDao {
	
	public int insert(Student s)
	{
		int res=0;
		PreparedStatement pst=null;
		Connection c=CommonCon.Connect();
		String sql="insert into student values(?,?,?)";
		try {
		    pst=c.prepareStatement(sql);
			pst.setInt(1, s.getStudID());
			pst.setString(2, s.getStudName());
			pst.setString(3, s.getMobile());
			  res=pst.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		 {
			 
			 try {
				pst.close();
				 c.close();
			} catch (SQLException e) {
				 
				e.printStackTrace();
			}
		 }
		
		return res;
	}

	}
