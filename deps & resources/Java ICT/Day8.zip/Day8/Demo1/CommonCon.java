package  pack1;
import java.io.*;
import java.sql.*;

 
 public class CommonCon {
	
	  
 
	public static Connection  Connect()
	
	{
		Connection c=null;
		 
		try
		{
     Class.forName("com.mysql.cj.jdbc.Driver"); 
      c=DriverManager.getConnection("jdbc:mysql://localhost:3306/training","root","manager");
      		 
    System.out.println("Connected");
	 	}
		
		catch( Exception e)
		{
			
		System.out.println(e);	
		}
		return c;
		}
	}
 
