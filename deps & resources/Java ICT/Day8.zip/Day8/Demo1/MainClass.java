package pack1;

import java.util.Scanner;

public class MainClass {

	int studId;
	String studName;
	String mobile;
	
	StudDao studDao=new StudDao();
	
	 void accept()
	 {
		 
		 Scanner scan=new Scanner(System.in); 
		 System.out.println("Enter student id,name & mobile no");
		 studId=scan.nextInt();
		 studName=scan.next();
		 mobile=scan.next();
	 }
	 
	 int insert()
	 {
		 Student s=new Student();
		 s.setStudID(studId);
		 s.setStudName(studName);
		 s.setMobile(mobile);
		 int res=studDao.insert(s);
		 return res;
	 }
	public static void main(String[] args) {
		

		MainClass obj=new MainClass();
		obj.accept();
		int res=obj.insert( );
		if (res>=1)
			System.out.println("Inserted successfully");
	}

}
