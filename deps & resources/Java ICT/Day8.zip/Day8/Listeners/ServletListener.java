 package com.pack1;

import javax.servlet.ServletContextEvent;


public class ServletListener implements javax.servlet.ServletContextListener {

	 public void contextInitialized(ServletContextEvent arg0) {
	    System.out.println("Servlet Context is initialized....");
	     
	   }

	  public void contextDestroyed(ServletContextEvent servletContextEvent) {
	    System.out.println("Servlet Context is destroyed....");
		/*
		 * Integer s=(Integer)servletContextEvent.
		 * getServletContext().getAttribute("sessionCount"); System.out.println(s);
		 */
		 
	  }
	} 
 
	
 /*@Override
public void contextInitialized(ServletContextEvent arg0) {
    System.out.println("Servlet Context is initialized....");
     
   }
@Override
  public void contextDestroyed(ServletContextEvent servletContextEvent) {
    System.out.println("Servlet Context is destroyed....");
	  Integer s=(Integer)servletContextEvent.getServletContext().getAttribute("sessionCount");
	  System.out.println(s);
	 
  }
*/

 
