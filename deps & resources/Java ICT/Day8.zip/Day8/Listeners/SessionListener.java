package com.pack1;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;

public class SessionListener implements javax.servlet.http.HttpSessionListener {
   static int count=0;
   
	  public void sessionCreated(HttpSessionEvent sessionEvent) {
	    System.out.println("Session is created");
	    /*count=count+1;
	    System.out.println(count);
	    ServletContext sContext = sessionEvent.getSession().getServletContext();
        
        sContext.setAttribute("sessionCount", count);*/

	  }

	  public void sessionDestroyed(HttpSessionEvent sessionEvent) {
		  //HttpSession session = sessionEvent.getSession();
      //   String u=(String)session.getAttribute("un");
		  System.out.println("session destroyed");
		  
        
         
          
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
         
	    
	   
	    
	  }
	} 
