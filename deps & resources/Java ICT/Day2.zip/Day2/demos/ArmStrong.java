import java.util.Scanner;


public class ArmStrong {

	 	  
	 static int numCheck;
	 
	 public static boolean  ArmstrongNum(int input1)
	 {
		 System.out.println("into");
		 numCheck=input1;
		int digit,sum=0,i;
		
		//for (; input1>0;input1=input1/10)
 	while (input1>0)
		{
		 
			digit=input1%10;//1%10 is 1
			sum=sum+(int)Math.pow(digit,3);//27+125+1
			 input1=input1/10;//15/10
			 
		 
		}
	 
		if (sum==numCheck)
			return true;
		else
			return false;
		 
	 }
	 
	 public static void main(String args[])
	 {
		 System.out.println("Enter no");
		 Scanner scan=new Scanner(System.in);
		  int num=scan.nextInt();
		  boolean b= ArmstrongNum(num);
			if (b)
				System.out.println("Armstrong no");
			else
				System.out.println("Not an Armstrong no");
		      
		 
	 }
}
