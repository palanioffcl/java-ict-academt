//TwoDim
class TwoD
{
public static void main(String args[])
{
/*int twod[][]=new int [4][4];
int i,j,k=0;

for (i=0;i<4;i++)
{
for(j=0;j<i+1;j++)
{
twod[i][j]=k;
k++;
}

}

for (i=0;i<4;i++)
{
for(j=0;j<i+1;j++)
{
System.out.print(twod[i][j]+" ");
}
System.out.println();
}

}
}*/



int twod[][]=new int [4][4];
int i,j,k=0;


/*
 * 
 * towD[0][0]=0
 * towD[0][1]=1
 * towD[0][2]=2
 * towD[0][3]=3
 * 
 * towD[1][0]=4
 * towD[1][1]=5
 * towD[1][2]=6
 * towD[1][3]=7
 */
for (i=0;i<4;i++)//i=0, j=0,1,2,3
{
for(j=0;j<4;j++)   
{
twod[i][j]=k;
k++;
}

}



for (i=0;i<4;i++)
{
for(j=0;j<4;j++)
{
System.out.print(twod[i][j]+"\t");

}
System.out.println();
}

}
}