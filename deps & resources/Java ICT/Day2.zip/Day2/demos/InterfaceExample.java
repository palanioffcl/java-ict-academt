
 
	
	import java.io.*;
	 
	interface marks_process
	{
		  void total_marks(int m1, int m2, int m3);
		  void grade_calc();
	}
	
	
	class stud_marks implements marks_process
	{
		int total;
		float avg;
		char stud_grade;
	
		public stud_marks()
	{ total=0; avg=0; stud_grade='\0';}
	
		public void total_marks(int m1, int m2, int m3)
		{ 
			total = m1+m2+m3;
		}
	
		public void grade_calc()
	{
	avg=total/3;
	if (avg>=90) stud_grade = 'O';
		else if (avg >=80 && avg <90) stud_grade='S';
			else if(avg >=70 && avg <80) stud_grade ='A';
				else if (avg >= 60 && avg <60) stud_grade ='B';
					else if (avg >= 50 && avg <60) stud_grade ='C';
						else stud_grade = 'F';
	}
		
		public void disp_data()
		{
			System.out.println("Total Marks ="+total);
			System.out.println("Average="+avg);
			System.out.println("Grade= " +stud_grade);
	}
	}
	
	
	public class InterfaceExample
	{
		public static void main(String[] args)
		{
		stud_marks s=new stud_marks();
		s.total_marks(80,70,60);
		s.grade_calc();		
		s.disp_data();
	}
	}


 
