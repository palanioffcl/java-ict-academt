import java.util.Scanner;
public class Palindrome {
	  String word ;
		 
	void accept(String word)
	{
		 this.word=word;
	}
		
	boolean check()
	{
	  StringBuffer sb=new StringBuffer();
	  int len=word.length();
	  char c;
	 	  for (int k=len-1;k>=0;k--)
	 	  {
	 		  c=word.charAt(k);
	 		  sb.append(c);
	 	  }
			
			String s=new String(sb);
			
			
			 
		if (s.equals(word))
		   return true;
		else
			return false;
	}

	public static void main(String[] args) {
	 
		Palindrome pal=new Palindrome();
		System.out.println("Enter a word");
		Scanner scan=new Scanner(System.in);
		String word=scan.next();
		 pal.accept(word);
		if(pal.check()==true)
			System.out.println("Palindrome");
		else
			System.out.println("Not a Palindrome");
	}

}
