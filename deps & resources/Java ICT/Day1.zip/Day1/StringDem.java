package review;

class StringDem
{ 

	public static void main (String args[]) 
	{ 
		
		  
		 String textString = new String ("java"); 
		StringBuffer text=new StringBuffer("java"); 
 
 textString=  textString.replace('j' , 'c');
	   text.append ("c");   
	  
		System.out.println(textString);
		System.out.println(text); 

	} 
}


