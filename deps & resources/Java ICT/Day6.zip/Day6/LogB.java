package com.fidelity.pack;


public class LogB implements javax.servlet.Filter {

	  public void init(javax.servlet.FilterConfig filterConfig) {
		  
	  }

	  public void doFilter(javax.servlet.ServletRequest request,
	                       javax.servlet.ServletResponse response,
	                       javax.servlet.FilterChain chain)
	  {
	    System.out.println("Entered LogB doFilter()");
	    System.out.println("protocol is " + request.getProtocol());
	    
	    System.out.println("port " + request.getLocalPort());
	    System.out.println("username is " + request.getParameter("user"));
	   
	   

	    try {
	        chain.doFilter(request, response);
	      } catch (Exception e) {
	        e.printStackTrace();
	      }
	  }

	  public void destroy() {
	  }
	}
