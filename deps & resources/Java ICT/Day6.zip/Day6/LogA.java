package com.fidelity.pack;

import java.io.IOException;

import javax.servlet.FilterConfig;

public class LogA implements javax.servlet.Filter {
	 

	  public void init(FilterConfig filterConfig) {
		 
		 	  }

	  public void doFilter(javax.servlet.ServletRequest request,
	          javax.servlet.ServletResponse response,
	          javax.servlet.FilterChain chain)throws IOException {
		
	  System.out.println("LogA passing request to next filter");
	    try {
	      chain.doFilter(request, response);
	    } catch (Exception e) {
	      e.printStackTrace();
	    }
	    System.out.println("The servlet has finished processing the request");
	   
	  
	  }

	  public void destroy() {
	  }
	}
