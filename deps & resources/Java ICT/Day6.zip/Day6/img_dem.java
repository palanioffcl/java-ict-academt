package com.fidelity.pack;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class for Servlet: img_dem
 *
 */
 public class img_dem extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet {
   static final long serialVersionUID = 1L;
   
    /* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */
	public img_dem() {
		super();
	}   	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			
		response.setContentType("image/jpeg");
		//String imagepath  = getServletContext().getRealPath(File.separator);
	   // String  path  = request.getContextPath();
	   // System.out.println(path); 
		File f = new File("d:/raptor_image.jpg");
	
	//	 File f=new File("E:/Servlets_Space_New/Servlets_Project/WebContent/raptor_image.jpg");
		 BufferedImage bi = ImageIO.read(f);
		 OutputStream out = response.getOutputStream();
	   		 
		 ImageIO.write(bi, "jpg", out);
	 
	}  	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}   	  	    
}