package com.fidelity.pack;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;

public class Login_Filter  implements javax.servlet.Filter {
	  // static final long serialVersionUID = 1L;
	   
	   FilterConfig filterConfig;
	    List blockedList;
         RequestDispatcher rd;
         
	    public void init(FilterConfig filterConfig) throws 
	    ServletException {
	    this.filterConfig = filterConfig;
	    blockedList = new  ArrayList(); 
	     readBlockedList();
	    }
	    
	    
	    public void doFilter(javax.servlet.ServletRequest request,
	            javax.servlet.ServletResponse response,
	            javax.servlet.FilterChain chain)throws IOException,ServletException {
	    
	    String username = request.getParameter("user");
	    System.out.println(blockedList);
	    if (blockedList.contains(username) )
	    { 	  
        rd= request.getRequestDispatcher( "/unauthorisederror.jsp");
        rd.forward( request, response);
	    }
	    else   if (!blockedList.contains(username) )
	    {
	    	rd=request.getRequestDispatcher( "/Success.html");
	    	rd.forward(request,response);	
	    }  
	    chain.doFilter(request, response);
	    
	    }
	  
	        
	    
	    //destroy method to clean up.
	    public void destroy() {
	    this.filterConfig = null;
	    blockedList = null;}
	 	    
	    
	    //method to read all blocked user list from the file  
	    private void readBlockedList() {
	    
	    if ( filterConfig != null ) {
	    
	    BufferedReader in;
	    String blockedUserName;
	    
	    try {
	    String filename = filterConfig.getInitParameter("BlockedUsers");
	    System.out.println("f "+filename);
	    in = new BufferedReader(new FileReader(filename));
	     	
	    	while ((blockedUserName = in.readLine()) != null ) 
	    blockedList.add(blockedUserName);}
	    catch (IOException ioe) {
	    	
	    	System.out.println(ioe);
	    	System.exit(0);
	    }
	    }
   }
	    
}
	 
	 
		