package com.fidelity.pack;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class for Servlet: Login_New
 *
 */
 public class Login_New extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet {
   static final long serialVersionUID = 1L;
   
    /* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */
	public Login_New() {
		super();
	}   	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}  	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("Start doPost in Login");
	 	 System.out.println("protocol inside servlet " + request.getProtocol());
	    String username = request.getParameter("user");
	    try {
	      response.setContentType("text/html");
	      PrintWriter writer = response.getWriter();
	     
	      writer.println("<html><body>");
	      writer.println("Thank you, " + username + 
	                     ". You are now logged into the system.");
	      writer.println("</body></html>");
	      writer.close();
	    System.out.println("End doPost in Login");
	    } catch (Exception e) {
	      e.printStackTrace();
	    }
	}   	  	
	}   	  	    
